public enum TileSide {
    FRONT, BACK, LEFT, RIGHT, TOP, BOTTOM, INVALID
}
