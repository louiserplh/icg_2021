
# Assignment 0

Please read the file `exercise0.html` carefully, where you can find this assignment's instructions.
