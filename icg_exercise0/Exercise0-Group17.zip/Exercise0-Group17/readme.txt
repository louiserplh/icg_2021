Task 0.1: Set your background color

We solved this exercise by modifying the values in the pix_color vector. Here, we first thought the values were encoded in 0-255 range, but quickly realized that it was actually 0-1 range.

Task 0.2: Modify the scene

After looking around the code for a while, we quickly realized that we needed to create a new material in the material list within the basic-sphere scene, and change the sphere radius and color in that same scene. The final result was saved in the basic-sphere.png file.

For this assignment, every group member contributed equally (33.3333% participation for each).